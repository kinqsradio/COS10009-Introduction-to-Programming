#require 'input'
def main()
    print 'Enter your name: '
    name = gets.chomp
    puts "Hello, #{name}!"
end

main
