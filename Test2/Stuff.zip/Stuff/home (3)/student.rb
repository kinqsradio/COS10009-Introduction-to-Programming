# Put your record definition here
# use the keywords class and attr_accessor
# remember each field must have a : before it e.g :field
# Don't have an initialize() method.

class Student
	attr_accessor :id, :first_name, :last_name, :course, :phone_number
end
