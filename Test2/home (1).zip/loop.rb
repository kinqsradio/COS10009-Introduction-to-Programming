
def main()
 # put your code here.
 # use puts(number) to print the number
    i = 0
    while i < 100
        puts i+1 
        i+=1
    end
end

main()
